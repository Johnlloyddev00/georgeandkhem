const DEFAULT_RECIPIENT = process.env.CONTACT_EMAIL || "hello@creativewebdev.team";
const DEFAULT_FROM = process.env.RESEND_FROM || "Creative Web Dev Team <onboarding@resend.dev>";

function escapeHtml(value = "") {
	return String(value)
		.replace(/&/g, "&amp;")
		.replace(/</g, "&lt;")
		.replace(/>/g, "&gt;")
		.replace(/\"/g, "&quot;")
		.replace(/'/g, "&#39;");
}

function getBrowserInfo() {
	const ua = typeof navigator !== "undefined" ? navigator.userAgent : "Unknown";
	const platform = typeof navigator !== "undefined" ? navigator.platform : "Unknown";
	return `${ua} | Platform: ${platform}`;
}

function getDeviceInfo() {
	if (typeof navigator === "undefined") return "Unknown";
	const isMobile = /Mobi|Android|iPhone|iPad|iPod/i.test(navigator.userAgent);
	return isMobile ? "Mobile" : "Desktop";
}

function formatSubmissionDetails(data) {
	const now = new Date();
	const timezone = data.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone || "Unknown";
	return {
		submittedAt: now.toISOString(),
		formattedTimestamp: now.toLocaleString("en-US", {
			dateStyle: "full",
			timeStyle: "long",
			timeZone: timezone,
		}),
		timezone,
		browser: data.browser || getBrowserInfo(),
		device: data.device || getDeviceInfo(),
		websiteUrl: data.websiteUrl || "Unknown",
	};
}

function buildEmailHtml(payload) {
	const details = formatSubmissionDetails(payload);
	const features = Array.isArray(payload.features) && payload.features.length
		? payload.features.join(", ")
		: "None selected";

	return `
		<!DOCTYPE html>
		<html>
		<head>
			<meta charset="utf-8" />
			<meta name="viewport" content="width=device-width, initial-scale=1.0" />
			<title>New Project Inquiry</title>
		</head>
		<body style="font-family: Arial, sans-serif; background:#f5f7fb; margin:0; padding:24px; color:#111827;">
			<div style="max-width:720px; margin:0 auto; background:#ffffff; border-radius:16px; overflow:hidden; border:1px solid #e5e7eb;">
				<div style="background:linear-gradient(135deg, #183fad 0%, #2446b8 100%); padding:24px 30px; color:#ffffff;">
					<h1 style="margin:0 0 8px; font-size:24px;">New Project Inquiry</h1>
					<p style="margin:0; font-size:14px; opacity:0.9;">A new project inquiry was submitted through the website contact form.</p>
				</div>
				<div style="padding:30px;">
					<h2 style="margin:0 0 16px; font-size:18px; color:#183fad;">Client Information</h2>
					<ul style="margin:0 0 24px; padding-left:20px; line-height:1.7;">
						<li><strong>Full Name:</strong> ${escapeHtml(payload.fullName || "Not provided")}</li>
						<li><strong>Email Address:</strong> ${escapeHtml(payload.email || "Not provided")}</li>
						<li><strong>Phone Number:</strong> ${escapeHtml(payload.phone || "Not provided")}</li>
						<li><strong>Company:</strong> ${escapeHtml(payload.company || "Not provided")}</li>
					</ul>

					<h2 style="margin:0 0 16px; font-size:18px; color:#183fad;">Project Information</h2>
					<ul style="margin:0 0 24px; padding-left:20px; line-height:1.7;">
						<li><strong>Project Type:</strong> ${escapeHtml(payload.projectType || "Not provided")}</li>
						<li><strong>Estimated Number of Pages:</strong> ${escapeHtml(payload.estimatedPages || "Not provided")}</li>
						<li><strong>Estimated Budget:</strong> ${escapeHtml(payload.estimatedInvestment || "Not provided")}</li>
						<li><strong>Required Features:</strong> ${escapeHtml(features)}</li>
					</ul>

					<h2 style="margin:0 0 16px; font-size:18px; color:#183fad;">Project Description</h2>
					<p style="margin:0 0 24px; line-height:1.7; white-space:pre-wrap;">${escapeHtml(payload.description || "No description provided")}</p>

					<h2 style="margin:0 0 16px; font-size:18px; color:#183fad;">Submission Details</h2>
					<ul style="margin:0; padding-left:20px; line-height:1.7;">
						<li><strong>Submission Date & Time:</strong> ${escapeHtml(details.formattedTimestamp)}</li>
						<li><strong>Website URL:</strong> ${escapeHtml(details.websiteUrl)}</li>
						<li><strong>Browser:</strong> ${escapeHtml(details.browser)}</li>
						<li><strong>Device:</strong> ${escapeHtml(details.device)}</li>
						<li><strong>Timezone:</strong> ${escapeHtml(details.timezone)}</li>
					</ul>
				</div>
			</div>
		</body>
		</html>
	`;
}

function readRequestBody(req) {
	return new Promise((resolve, reject) => {
		let body = "";
		req.on("data", (chunk) => {
			body += chunk;
		});
		req.on("end", () => resolve(body));
		req.on("error", reject);
	});
}

module.exports = async function handler(req, res) {
	res.setHeader("Access-Control-Allow-Origin", "*");
	res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
	res.setHeader("Access-Control-Allow-Headers", "Content-Type");

	if (req.method === "OPTIONS") {
		res.status(204).end();
		return;
	}

	if (req.method !== "POST") {
		res.status(405).json({ success: false, message: "Method not allowed." });
		return;
	}

	const apiKey = process.env.RESEND_API_KEY;
	const recipientEmail = process.env.CONTACT_EMAIL || DEFAULT_RECIPIENT;
	const senderAddress = process.env.RESEND_FROM || DEFAULT_FROM;

	if (!apiKey) {
		res.status(500).json({
			success: false,
			message: "Email service is not configured. Set RESEND_API_KEY in your environment variables.",
		});
		return;
	}

	if (!recipientEmail) {
		res.status(500).json({
			success: false,
			message: "No recipient email is configured. Set CONTACT_EMAIL in your environment variables.",
		});
		return;
	}

	let payload = {};
	try {
		const rawBody = await readRequestBody(req);
		payload = rawBody ? JSON.parse(rawBody) : {};
	} catch (error) {
		res.status(400).json({ success: false, message: "The request body could not be parsed." });
		return;
	}

	const projectType = payload.projectType || "Custom Project";
	const response = await fetch("https://api.resend.com/emails", {
		method: "POST",
		headers: {
			Authorization: `Bearer ${apiKey}`,
			"Content-Type": "application/json",
		},
		body: JSON.stringify({
			from: senderAddress,
			to: [recipientEmail],
			reply_to: payload.email || recipientEmail,
			subject: `New Project Inquiry - ${projectType}`,
			html: buildEmailHtml({
				...payload,
				websiteUrl: payload.websiteUrl || "Unknown",
			}),
		}),
	});

	if (!response.ok) {
		const errorText = await response.text();
		res.status(502).json({
			success: false,
			message: "Could not send the inquiry email.",
			details: errorText,
		});
		return;
	}

	res.status(200).json({ success: true, message: "Inquiry email sent successfully." });
};
