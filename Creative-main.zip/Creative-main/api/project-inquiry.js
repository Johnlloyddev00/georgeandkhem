// This API route uses server-side environment variables only.
// SMTP credentials should never be exposed to the frontend.
const { sanitizeText, sanitizeHtml, validateInquiryPayload } = require("../lib/validation");
const { sendInquiryEmail } = require("../lib/emailService");

function getClientIp(req) {
	return req.headers["x-forwarded-for"] || req.socket?.remoteAddress || "unknown";
}

const rateLimitMap = new Map();

function checkRateLimit(ip) {
	const now = Date.now();
	const windowMs = 60_000;
	const maxRequests = 5;
	const entries = rateLimitMap.get(ip) || [];
	const recent = entries.filter((timestamp) => now - timestamp < windowMs);
	if (recent.length >= maxRequests) {
		return false;
	}
	recent.push(now);
	rateLimitMap.set(ip, recent);
	return true;
}

module.exports = async function handler(req, res) {
	res.setHeader("Access-Control-Allow-Origin", "*");
	res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
	res.setHeader("Access-Control-Allow-Headers", "Content-Type");

	if (req.method === "OPTIONS") {
		res.status(204).end();
		return;
	}

	if (req.method !== "POST") {
		res.status(405).json({ success: false, message: "Failed to send inquiry." });
		return;
	}

	const clientIp = getClientIp(req);
	if (!checkRateLimit(clientIp)) {
		res.status(429).json({ success: false, message: "Too many requests. Please try again shortly." });
		return;
	}

	let body = "";
	try {
		body = await new Promise((resolve, reject) => {
			let data = "";
			req.on("data", (chunk) => {
				data += chunk;
				if (data.length > 20000) {
					req.destroy();
				}
			});
			req.on("end", () => resolve(data));
			req.on("error", reject);
		});
	} catch (error) {
		res.status(413).json({ success: false, message: "Failed to send inquiry." });
		return;
	}

	let payload = {};
	try {
		payload = body ? JSON.parse(body) : {};
	} catch (error) {
		res.status(400).json({ success: false, message: "Failed to send inquiry." });
		return;
	}

	const sanitizedPayload = {
		fullName: sanitizeText(payload.fullName),
		email: sanitizeText(payload.email),
		phone: sanitizeText(payload.phone),
		company: sanitizeText(payload.company),
		projectType: sanitizeText(payload.projectType),
		estimatedPages: sanitizeText(payload.estimatedPages),
		estimatedBudget: sanitizeText(payload.estimatedBudget),
		description: sanitizeText(payload.description),
		websiteUrl: sanitizeText(payload.websiteUrl),
		browser: sanitizeText(payload.browser),
		operatingSystem: sanitizeText(payload.operatingSystem),
		screenResolution: sanitizeText(payload.screenResolution),
		timezone: sanitizeText(payload.timezone),
	};

	const errors = validateInquiryPayload(sanitizedPayload);
	if (errors.length) {
		res.status(400).json({ success: false, message: errors[0] });
		return;
	}

	try {
		await sendInquiryEmail(sanitizedPayload);
		res.status(200).json({ success: true, message: "Inquiry sent successfully." });
	} catch (error) {
		const errorMessage = error?.message || "Failed to send inquiry.";
		res.status(500).json({ success: false, message: errorMessage });
	}
};
