const fs = require('fs');
const text = fs.readFileSync('index.js', 'utf8');
const servicesMatch = text.match(/const services = \[([\s\S]*?)\];/m);
console.log('matched services', !!servicesMatch);
if (!servicesMatch) process.exit(0);
const servicesText = servicesMatch[1];
const iconRe = /icon: `([\s\S]*?)`,\s*\n/g;
let match;
let idx = 0;
while ((match = iconRe.exec(servicesText))) {
  idx += 1;
  const icon = match[1];
  const paths = [...icon.matchAll(/<path[^>]*d=("|')([^"']*)\1/g)];
  console.log('SERVICE', idx, 'paths', paths.length);
  paths.forEach((p, j) => {
    console.log(' ', j + 1, p[2].slice(0, 100));
  });
}
