# Creative Web Dev Team

## Inquiry email setup

1. Create a Vercel project from this folder.
2. Add the following environment variables in Vercel:
   - SMTP_HOST
   - SMTP_PORT
   - SMTP_USER
   - SMTP_PASSWORD
   - SMTP_SECURE
   - CONTACT_EMAIL
   - FROM_EMAIL
3. Deploy the project.
4. Submit the inquiry form to send an email to the configured address.

The form submits to `/api/project-inquiry`, which uses Node.js and Nodemailer to send the inquiry email through your SMTP server with the client email set as the reply-to address.

