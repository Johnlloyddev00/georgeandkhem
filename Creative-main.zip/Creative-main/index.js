const digitalSolutionIcon = `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-5"><path stroke-linecap="round" stroke-linejoin="round" d="M3.75 3v11.25A2.25 2.25 0 006 16.5h2.25M3.75 3h16.5M3.75 3v-.75A.75.75 0 014.5 1.5h15a.75.75 0 01.75.75V3m0 0v11.25A2.25 2.25 0 0118 16.5h-2.25m-7.5 0h7.5m-7.5 0l-1 3m8.5-3 1 3m0 0 .5 1.5m-.5-1.5h-9.5m0 0L6.75 21" /></svg>`;

const services = [
	{ name: "Business Website", description: "A professional website that builds trust and turns visitors into inquiries.", tags: ["HTML", "CSS", "JavaScript"], category: "Websites", icon: digitalSolutionIcon },
	{ name: "Corporate Website", description: "A structured digital presence for established companies, teams, and services.", tags: ["Next.js", "CMS", "SEO"], category: "Websites", icon: digitalSolutionIcon },
	{ name: "Landing Page", description: "A focused page designed to promote an offer and generate qualified leads.", tags: ["HTML", "Tailwind", "Analytics"], category: "Websites", icon: digitalSolutionIcon },
	{ name: "E-Commerce Website", description: "A secure online store that simplifies product sales, payments, and orders.", tags: ["React", "Payments", "MySQL"], category: "Commerce", icon: digitalSolutionIcon },
	{ name: "Custom Web Application", description: "Software built around your workflow, users, and business requirements.", tags: ["React", "Laravel", "Supabase"], category: "Custom Software", icon: digitalSolutionIcon },
	{ name: "Inventory Management System", description: "Track products, stock movement, suppliers, and low-stock alerts.", tags: ["Laravel", "MySQL", "Reports"], category: "Operations", icon: digitalSolutionIcon },
	{ name: "Booking & Reservation System", description: "Manage availability, appointments, customers, and confirmations online.", tags: ["React", "Supabase", "Email"], category: "Operations", icon: digitalSolutionIcon },
	{ name: "Point of Sale (POS)", description: "Process sales, manage products, and monitor daily business performance.", tags: ["PHP", "MySQL", "Analytics"], category: "Retail Systems", icon: digitalSolutionIcon },
	{ name: "School Management System", description: "Organize student records, classes, grades, billing, and reporting.", tags: ["Laravel", "MySQL", "Roles"], category: "Education", icon: digitalSolutionIcon },
	{ name: "CRM System", description: "Centralize leads, customer activity, follow-ups, and sales opportunities.", tags: ["React", "API", "Database"], category: "Sales Systems", icon: digitalSolutionIcon },
	{ name: "HRIS", description: "Manage employee records, attendance, leave, and workforce information.", tags: ["Laravel", "MySQL", "Security"], category: "HR Systems", icon: digitalSolutionIcon },
	{ name: "Admin Dashboard", description: "Monitor key metrics and manage business data from one clear interface.", tags: ["React", "Charts", "API"], category: "Analytics", icon: digitalSolutionIcon },
	{ name: "Customer Portal", description: "Give customers secure access to accounts, requests, files, and updates.", tags: ["Auth", "React", "Supabase"], category: "Customer Experience", icon: digitalSolutionIcon },
	{ name: "API Integration", description: "Connect your systems with payments, logistics, messaging, and other tools.", tags: ["REST API", "Webhooks", "Node.js"], category: "Integration", icon: digitalSolutionIcon },
	{ name: "SEO Optimization", description: "Improve search visibility, site structure, speed, and discoverability.", tags: ["SEO", "Analytics", "Performance"], category: "Growth", icon: digitalSolutionIcon },
	{ name: "Website Maintenance", description: "Keep your website secure, updated, backed up, and performing reliably.", tags: ["Security", "Backups", "Support"], category: "Support", icon: digitalSolutionIcon },
];

const businessSolutions = [
	{ title: "Inventory System", description: "Track stock, suppliers, movements, and reorder levels in real time." },
	{ title: "Booking System", description: "Manage schedules, reservations, availability, and customer notifications." },
	{ title: "POS System", description: "Process sales and monitor products, transactions, and daily revenue." },
	{ title: "HRIS", description: "Centralize employee records, attendance, leave, and HR workflows." },
	{ title: "CRM", description: "Organize leads, customer relationships, follow-ups, and sales activity." },
	{ title: "School Management System", description: "Manage students, classes, grades, billing, and school operations." },
	{ title: "Restaurant Ordering System", description: "Accept and manage dine-in, pickup, and delivery orders efficiently." },
	{ title: "Admin Dashboard", description: "Control users, content, records, and operations from one interface." },
	{ title: "E-Commerce Platform", description: "Sell products through a secure, scalable online storefront." },
	{ title: "Customer Portal", description: "Provide secure self-service access to customer accounts and requests." },
	{ title: "Analytics Dashboard", description: "Turn operational data into clear reports and actionable insights." },
	{ title: "Project Management System", description: "Coordinate tasks, timelines, teams, files, and project progress." },
];

const industries = [
	"Restaurants", "Retail Stores", "Schools", "Construction", "Real Estate",
	"Clinics", "Hotels", "Salons", "Travel Agencies", "Manufacturing",
	"Startups", "Professional Services", "Government", "SMEs",
];

const portfolioProjects = [
	{
		id: 8,
		title: "BookClips",
		description: "A mobile-first book discovery platform that connects readers with books through engaging short-form clips.",
		thumbnail: "assets/projects/bookclips.png",
		technologies: ["HTML", "CSS", "JavaScript"],
		category: "Media Platform",
		status: "Live",
		liveUrl: "https://bookclips.net/",
		githubUrl: "",
		featured: true,
		useLivePreview: false,
		year: "2026",
	},
	{
		id: 7,
		title: "Creatives Center",
		description: "A web solutions and developer hub connecting businesses with custom digital services and creative talent.",
		thumbnail: "assets/projects/creative-center.png",
		technologies: ["React", "Tailwind CSS", "JavaScript"],
		category: "Agency Platform",
		status: "Live",
		liveUrl: "https://creatives-centers.vercel.app/",
		githubUrl: "",
		featured: true,
		useLivePreview: false,
		year: "2026",
	},
	{
		id: 9,
		title: "Rod Martin Artist",
		description: "An immersive artist portfolio showcasing Rod Martin's poetry, books, music, videos, and creative journey.",
		thumbnail: "assets/projects/rod-martin-artist.png",
		technologies: ["HTML", "CSS", "JavaScript"],
		category: "Artist Portfolio",
		status: "Live",
		liveUrl: "https://www.rodmartinartist.com/",
		githubUrl: "",
		featured: true,
		useLivePreview: false,
		year: "2025",
	},
	{
		id: 10,
		title: "Rod Martin Publishing",
		description: "A publishing platform featuring books, audiovisual media, author content, and creative resources.",
		thumbnail: "assets/projects/rod-martin-publishing.png",
		technologies: ["HTML", "CSS", "JavaScript"],
		category: "Publishing Website",
		status: "Live",
		liveUrl: "https://rodmartinartistpublishingllc.com/",
		githubUrl: "",
		featured: false,
		useLivePreview: false,
		year: "2025",
	},
	{
		id: 1,
		title: "Restaurant Website",
		description: "A modern, mobile-first restaurant site built to showcase menus and drive reservations.",
		thumbnail: "",
		technologies: ["HTML", "CSS", "JavaScript"],
		category: "Business Website",
		status: "Coming Soon",
		liveUrl: "",
		githubUrl: "",
		featured: true,
		useLivePreview: false,
		year: "2026",
	},
	{
		id: 2,
		title: "Booking System",
		description: "A streamlined scheduling platform with availability, customer, and booking management.",
		thumbnail: "",
		technologies: ["React", "Supabase", "TypeScript"],
		category: "Web Application",
		status: "Development",
		liveUrl: "",
		githubUrl: "",
		featured: false,
		useLivePreview: false,
		year: "2026",
	},
	{
		id: 3,
		title: "E-Commerce Store",
		description: "A responsive storefront designed for fast product discovery and secure checkout.",
		thumbnail: "",
		technologies: ["Next.js", "Node.js", "MySQL"],
		category: "E-Commerce",
		status: "Coming Soon",
		liveUrl: "",
		githubUrl: "",
		featured: false,
		useLivePreview: false,
		year: "2026",
	},
	{
		id: 4,
		title: "School Management System",
		description: "An integrated portal for student records, classes, reporting, and administration.",
		thumbnail: "",
		technologies: ["Laravel", "PHP", "MySQL"],
		category: "Management System",
		status: "Private",
		liveUrl: "",
		githubUrl: "",
		featured: true,
		useLivePreview: false,
		year: "2026",
	},
	{
		id: 5,
		title: "Company Landing Page",
		description: "A conversion-focused company website with clear services and lead generation paths.",
		thumbnail: "",
		technologies: ["HTML", "CSS", "JavaScript"],
		category: "Business Website",
		status: "Coming Soon",
		liveUrl: "",
		githubUrl: "",
		featured: false,
		useLivePreview: false,
		year: "2026",
	},
	{
		id: 6,
		title: "Admin Dashboard",
		description: "A clean analytics dashboard for monitoring activity, users, and business performance.",
		thumbnail: "",
		technologies: ["React", "Firebase", "TypeScript"],
		category: "Dashboard",
		status: "Development",
		liveUrl: "",
		githubUrl: "",
		featured: false,
		useLivePreview: false,
		year: "2026",
	},
];

const DEFAULT_PORTFOLIO_THUMBNAIL =
	"assets/projects/project-placeholder.svg";

const technologies = [
	"HTML",
	"CSS",
	"JavaScript",
	"TypeScript",
	"React",
	"Next.js",
	"Node.js",
	"PHP",
	"Laravel",
	"Supabase",
	"Firebase",
	"MySQL",
	"Git",
	"Docker",
	"Figma",
];

const ease =
	"after:transition-[width,left] after:duration-2000 after:ease-[linear(0,0.014_0.4%,0.054_0.8%,0.228_1.7%,1.141_4.6%,1.402_5.6%,1.565_6.6%,1.599_7%,1.617_7.5%,1.611_7.9%,1.58_8.4%,1.47_9.3%,0.924_12.1%,0.747_13.2%,0.655_14.1%,0.633_14.5%,0.62_15%,0.622_15.4%,0.639_15.9%,0.705_16.8%,1.052_19.7%,1.159_20.8%,1.214_21.7%,1.235_22.6%,1.221_23.5%,1.18_24.4%,0.972_27.2%,0.905_28.3%,0.869_29.2%,0.855_30.1%,0.862_31%,0.887_31.9%,1.06_35.9%,1.081_36.8%,1.089_37.7%,1.084_38.6%,1.069_39.5%,0.964_43.4%,0.945_45.2%,0.954_46.8%,1.019_50.7%,1.034_52.7%,1.029_54.3%,0.989_58.2%,0.979_60.3%,1.013_67.8%,0.992_75.3%,1.005_82.7%,0.997_90.4%,1)]";

function renderServices() {
	const list = document.getElementById("services-grid");
	if (!list) return;

	list.innerHTML = services
		.map(
			(service) => `
		<li class="col-span-1 flex flex-col rounded-3xl overflow-hidden">
			<div>
				<div class="flex">
					<div class="pl-3 flex-1 bg-[#e9ecf6] flex flex-wrap gap-1.5 items-center py-2 rounded-tr-2xl relative after:content-[''] after:absolute after:top-0 after:right-0 after:h-1/2 after:w-1/2 after:bg-white after:-z-[1]">
						${service.tags
							.map(
								(tag) =>
									`<span class="text-xs font-semibold bg-white/80 px-2 py-0.5 rounded-full text-brand-blue">${tag}</span>`
							)
							.join("")}
					</div>
					<div class="flex items-center gap-1 bg-white pl-1.5 pr-px pt-1 pb-1.5 rounded-bl-3xl rounded-tr-3xl relative after:content-[''] after:absolute after:bottom-0 after:left-0 after:h-1/2 after:w-1/2 after:bg-[#e9ecf6] after:-z-[1]">
						<a href="#contact" aria-label="Start project for ${service.name}" class="flex items-center bg-[#F1BF0A] rounded-full p-1.25 text-[#090909] whitespace-nowrap relative after:content-[''] after:absolute after:top-1/2 after:-translate-y-1/2 after:left-1.25 after:rounded-full after:bg-white after:w-8 after:h-8 sm:after:h-5.5 sm:after:w-5.5 ${ease} overflow-hidden hover:after:size-full hover:after:left-0 cursor-pointer border border-[#F1BF0A]">
							<span class="rounded-full p-1.5 sm:p-1 relative z-10">${service.icon}</span>
						</a>
					</div>
				</div>
				<h3 class="pl-3 text-sm py-2 truncate bg-[#e9ecf6] rounded-tr-3xl font-semibold">${service.name}</h3>
			</div>
			<div class="flex flex-1 flex-col px-3 pb-4 pt-1 bg-[#e9ecf6]">
				<span class="mb-2 w-fit rounded-full bg-brand-blue/10 px-2.5 py-1 text-xs font-semibold text-brand-blue">${service.category}</span>
				<p class="text-sm text-brand-ink/75 leading-relaxed">${service.description}</p>
			</div>
		</li>`
		)
		.join("");
}

function renderBusinessSolutions() {
	const list = document.getElementById("business-solutions-list");
	if (!list) return;

	list.innerHTML = businessSolutions
		.map(
			(solution) => `
		<li class="group flex h-full flex-col rounded-3xl bg-[#e9ecf6] p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-md">
			<span class="inline-flex size-12 items-center justify-center rounded-2xl bg-brand-yellow text-brand-ink transition-transform duration-300 group-hover:scale-105">
				${digitalSolutionIcon}
			</span>
			<h3 class="mt-5 font-anton text-2xl leading-tight">${solution.title}</h3>
			<p class="mt-2 text-sm leading-relaxed text-brand-ink/70">${solution.description}</p>
		</li>`
		)
		.join("");
}

function renderIndustries() {
	const list = document.getElementById("industries-list");
	if (!list) return;

	list.innerHTML = industries
		.map(
			(industry) => `
		<li class="rounded-full border border-transparent bg-[#e9ecf6] px-4 py-2.5 text-sm font-semibold transition-colors hover:border-brand-yellow hover:bg-brand-yellow/20">
			${industry}
		</li>`
		)
		.join("");
}

function renderPortfolio() {
	const list = document.getElementById("portfolio-list");
	if (!list) return;

	const statusClasses = {
		Live: "bg-emerald-100 text-emerald-800",
		"Coming Soon": "bg-brand-yellow/25 text-brand-ink",
		Private: "bg-slate-200 text-slate-700",
		Featured: "bg-brand-yellow text-brand-ink",
		Development: "bg-brand-blue/15 text-brand-blue",
	};

	const githubIcon = `
		<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" class="size-5">
			<path d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z"/>
		</svg>`;

	list.innerHTML = portfolioProjects
		.map((project, index) => {
			const hasLiveUrl = Boolean(project.liveUrl);
			const thumbnail =
				project.thumbnail || DEFAULT_PORTFOLIO_THUMBNAIL;
			const statusClass =
				statusClasses[project.status] || "bg-slate-200 text-slate-700";
			const featuredClass = project.featured
				? "border-2 border-brand-yellow"
				: "border border-brand-blue/5";
			const cardLink = hasLiveUrl
				? `<a href="${project.liveUrl}" target="_blank" rel="noopener noreferrer" class="absolute inset-0 z-20 rounded-3xl focus:outline-none focus-visible:ring-4 focus-visible:ring-brand-yellow/70" aria-label="View ${project.title} project"></a>`
				: "";
			const githubButton = project.githubUrl
				? `<a href="${project.githubUrl}" target="_blank" rel="noopener noreferrer" class="absolute right-4 top-4 z-30 inline-flex size-9 items-center justify-center rounded-full bg-white text-brand-ink shadow-sm transition-transform hover:scale-110 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-yellow" aria-label="View ${project.title} source code on GitHub">${githubIcon}</a>`
				: "";

			return `
		<li class="portfolio-card col-span-1 h-full" data-index="${index}" data-project-id="${project.id}">
			<article class="group relative flex h-full flex-col overflow-hidden rounded-3xl bg-[#e9ecf6] shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-xl ${featuredClass}" ${hasLiveUrl ? "" : 'aria-disabled="true"'}>
				${cardLink}
				${githubButton}
				<div class="relative m-2 mb-0 overflow-hidden rounded-2xl bg-brand-blue">
					<img src="${thumbnail}" alt="Website preview for ${project.title}" class="aspect-[16/10] w-full object-cover transition-transform duration-500 group-hover:scale-105" loading="lazy" onerror="this.onerror=null;this.src='${DEFAULT_PORTFOLIO_THUMBNAIL}'" />
					<div class="absolute inset-0 z-10 flex items-center justify-center bg-brand-blue/75 opacity-0 transition-opacity duration-300 group-hover:opacity-100 group-focus-within:opacity-100">
						<span class="rounded-full bg-brand-yellow px-4 py-2 text-sm font-semibold text-brand-ink">
							${hasLiveUrl ? "View Project ↗" : "Coming Soon"}
						</span>
					</div>
				</div>

				<div class="flex flex-1 flex-col p-5">
					<div class="flex flex-wrap items-center gap-2">
						<span class="rounded-full bg-white/80 px-2.5 py-1 text-xs font-semibold text-brand-blue">${project.category}</span>
						<span class="rounded-full px-2.5 py-1 text-xs font-semibold ${statusClass}">${project.status}</span>
						${project.featured ? '<span class="rounded-full bg-brand-yellow px-2.5 py-1 text-xs font-bold text-brand-ink">Featured</span>' : ""}
						<span class="ml-auto text-xs font-semibold text-brand-ink/45">${project.year}</span>
					</div>

					<h3 class="mt-4 font-anton text-2xl leading-tight">${project.title}</h3>
					<p class="mt-2 flex-1 text-sm leading-relaxed text-brand-ink/65">${project.description}</p>

					<ul class="mt-5 flex flex-wrap gap-2" aria-label="Technologies used">
						${project.technologies
							.map(
								(technology) =>
									`<li class="rounded-full bg-white/80 px-2.5 py-1 text-xs font-semibold text-brand-ink/65">${technology}</li>`
							)
							.join("")}
					</ul>
				</div>
			</article>
		</li>`;
		})
		.join("");
}

function renderTechnologies() {
	const list = document.getElementById("tech-list");
	if (!list) return;

	list.innerHTML = technologies
		.map(
			(tech) => `
		<li class="bg-[#e9ecf6] text-brand-ink font-semibold text-sm px-4 py-2.5 rounded-full border border-transparent hover:border-brand-yellow hover:bg-brand-yellow/20 transition-colors">
			${tech}
		</li>`
		)
		.join("");
}

function setupPortfolioSlider() {
	const cards = () => [...document.querySelectorAll(".portfolio-card")];
	let active = 0;

	const highlight = () => {
		const items = cards();
		if (!items.length) return;
		items.forEach((card, i) => {
			card.classList.toggle("ring-2", i === active);
			card.classList.toggle("ring-brand-yellow", i === active);
			card.classList.toggle("scale-[1.02]", i === active);
			card.classList.add("transition-transform", "duration-300");
		});
		items[active]?.scrollIntoView({ behavior: "smooth", block: "nearest", inline: "center" });
	};

	const prev = document.getElementById("portfolio-prev");
	const next = document.getElementById("portfolio-next");

	prev?.addEventListener("click", () => {
		const items = cards();
		if (!items.length) return;
		active = (active - 1 + items.length) % items.length;
		highlight();
	});

	next?.addEventListener("click", () => {
		const items = cards();
		if (!items.length) return;
		active = (active + 1) % items.length;
		highlight();
		document.getElementById("portfolio")?.scrollIntoView({ behavior: "smooth", block: "start" });
	});
}

function setupMobileMenu() {
	const toggle = document.getElementById("menu-toggle");
	const menu = document.getElementById("mobile-menu");
	if (!toggle || !menu) return;

	toggle.addEventListener("click", () => {
		const open = menu.classList.toggle("hidden");
		toggle.setAttribute("aria-expanded", String(!open));
	});

	menu.querySelectorAll("a, button").forEach((link) => {
		link.addEventListener("click", () => {
			menu.classList.add("hidden");
			toggle.setAttribute("aria-expanded", "false");
		});
	});
}

function setupInquiryModal() {
	const backdrop = document.getElementById("inquiry-modal-backdrop");
	const closeButton = document.getElementById("inquiry-modal-close");
	const cancelButton = document.getElementById("inquiry-cancel");
	const form = document.getElementById("inquiry-form");
	const successState = document.getElementById("inquiry-success");
	const submitButton = document.getElementById("inquiry-submit");
	const closeSuccessButton = document.getElementById("inquiry-close-success");
	const statusMessage = document.getElementById("inquiry-status");
	const triggerButtons = document.querySelectorAll(
		'[data-open-inquiry-modal], a[href="#contact"]'
	);
	const uploadZone = document.getElementById("upload-zone");
	const uploadInput = document.getElementById("reference-files");
	const uploadedFilesList = document.getElementById("uploaded-files");
	const referenceDisplay = document.getElementById("inquiry-reference");
	let uploadedFiles = [];
	let inquiryCounter = 125;

	if (!backdrop || !form || !submitButton || !statusMessage) return;

	function resetModalState() {
		form.hidden = false;
		successState.hidden = true;
		form.reset();
		uploadedFiles = [];
		renderUploadedFiles();
		clearErrors();
		statusMessage.textContent = "";
		statusMessage.classList.remove("is-success");
		submitButton.disabled = false;
		submitButton.classList.remove("is-loading");
		submitButton.innerHTML = '<span class="inquiry-btn__label">Send Inquiry</span>';
	}

	function openModal() {
		backdrop.classList.add("is-open");
		backdrop.setAttribute("aria-hidden", "false");
		document.body.classList.add("no-scroll");
		resetModalState();
		updateInquiryInvestmentOptions();
		setTimeout(() => form.querySelector("input, select, textarea")?.focus(), 80);
	}

	function closeModal() {
		backdrop.classList.remove("is-open");
		backdrop.setAttribute("aria-hidden", "true");
		document.body.classList.remove("no-scroll");
	}

	function clearErrors() {
		form.querySelectorAll(".field-group").forEach((group) => {
			group.classList.remove("is-invalid");
			const errorElement = group.querySelector(".field-error");
			if (errorElement) {
				errorElement.textContent = "";
			}
		});
	}

	function showErrors() {
		let hasErrors = false;
		const requiredFields = [
			{ field: form.elements.fullName, message: "Please enter your full name." },
			{ field: form.elements.email, message: "Please enter your email address." },
			{ field: form.elements.projectType, message: "Please choose a project type." },
			{ field: form.elements.description, message: "Please share a brief project description." },
		];

		requiredFields.forEach(({ field, message }) => {
			const group = field?.closest(".field-group");
			if (!field || !group) return;
			const errorElement = group.querySelector(".field-error");

			if (field.name === "email" && field.value.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(field.value)) {
				group.classList.add("is-invalid");
				if (errorElement) {
					errorElement.textContent = "Please enter a valid email address.";
				}
				hasErrors = true;
				return;
			}

			if (field.value.trim() === "") {
				group.classList.add("is-invalid");
				if (errorElement) {
					errorElement.textContent = message;
				}
				hasErrors = true;
			} else {
				group.classList.remove("is-invalid");
				if (errorElement) {
					errorElement.textContent = "";
				}
			}
		});

		return !hasErrors;
	}

	function renderUploadedFiles() {
		if (!uploadedFilesList) return;
		uploadedFilesList.innerHTML = uploadedFiles.length
			? uploadedFiles.map((file) => `<li>${file.name}</li>`).join("")
			: "";
	}

	function handleFiles(fileList) {
		const files = Array.from(fileList || []);
		if (!files.length) return;
		uploadedFiles = [...uploadedFiles, ...files];
		renderUploadedFiles();
	}

	function showSuccessState() {
		form.hidden = true;
		successState.hidden = false;
		statusMessage.textContent = "";
		statusMessage.classList.remove("is-success");
		const nextReference = `CWDT-${new Date().getFullYear()}-${String(inquiryCounter).padStart(5, "0")}`;
		inquiryCounter += 1;
		if (referenceDisplay) referenceDisplay.textContent = nextReference;
	}

	triggerButtons.forEach((button) => {
		button.addEventListener("click", (event) => {
			if (button.tagName.toLowerCase() === "a" && button.getAttribute("href") === "#contact") {
				event.preventDefault();
			}
			openModal();
		});
	});

	[closeButton, cancelButton, closeSuccessButton].forEach((button) => {
		button?.addEventListener("click", closeModal);
	});

	backdrop.addEventListener("click", (event) => {
		if (event.target === backdrop) {
			closeModal();
		}
	});

	document.addEventListener("keydown", (event) => {
		if (event.key === "Escape" && backdrop.classList.contains("is-open")) {
			closeModal();
		}
	});

	if (uploadZone && uploadInput) {
		uploadZone.addEventListener("click", () => uploadInput.click());
		uploadZone.addEventListener("dragenter", (event) => {
			event.preventDefault();
			uploadZone.classList.add("is-dragover");
		});
		uploadZone.addEventListener("dragover", (event) => {
			event.preventDefault();
			uploadZone.classList.add("is-dragover");
		});
		uploadZone.addEventListener("dragleave", () => {
			uploadZone.classList.remove("is-dragover");
		});
		uploadZone.addEventListener("drop", (event) => {
			event.preventDefault();
			uploadZone.classList.remove("is-dragover");
			handleFiles(event.dataTransfer?.files);
		});
		uploadInput.addEventListener("change", (event) => {
			handleFiles(event.target.files);
			event.target.value = "";
		});
	}

	form.addEventListener("submit", async (event) => {
		event.preventDefault();
		clearErrors();
		if (!showErrors()) return;

		submitButton.disabled = true;
		submitButton.classList.add("is-loading");
		submitButton.innerHTML = '<span class="inquiry-btn__spinner" aria-hidden="true"></span><span class="inquiry-btn__label">Sending Inquiry...</span>';
		statusMessage.textContent = "";
		statusMessage.classList.remove("is-success");

		const formData = new FormData(form);
		const selectedFeatures = formData.getAll("features");
		const payload = {
			fullName: formData.get("fullName")?.toString().trim() || "",
			email: formData.get("email")?.toString().trim() || "",
			phone: formData.get("phone")?.toString().trim() || "",
			company: formData.get("company")?.toString().trim() || "",
			projectType: formData.get("projectType")?.toString().trim() || "",
			estimatedPages: formData.get("estimatedPages")?.toString().trim() || "",
			estimatedBudget: formData.get("estimatedInvestment")?.toString().trim() || "",
			features: selectedFeatures,
			description: formData.get("description")?.toString().trim() || "",
			websiteUrl: window.location.href,
			browser: navigator.userAgent || "Unknown",
			operatingSystem: navigator.platform || "Unknown",
			screenResolution: `${window.screen?.width || "Unknown"}x${window.screen?.height || "Unknown"}`,
			timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || "Unknown",
		};

		try {
			const response = await fetch("/api/project-inquiry", {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(payload),
			});

			const result = await response.json().catch(() => ({}));

			if (!response.ok || !result.success) {
				throw new Error(result.message || "Unable to send inquiry.");
			}

			showSuccessState();
			statusMessage.textContent = "Thank you! Your inquiry has been submitted successfully. We'll review your project requirements and contact you within 24 hours.";
			statusMessage.classList.add("is-success");
		} catch (error) {
			const fallbackMessage = "Unable to send your inquiry at this time. Please make sure the backend is running locally or try again later.";
			statusMessage.textContent = error?.message || fallbackMessage;
			statusMessage.classList.remove("is-success");
			submitButton.disabled = false;
			submitButton.classList.remove("is-loading");
			submitButton.innerHTML = '<span class="inquiry-btn__label">Send Inquiry</span>';
			console.error("Inquiry submission failed", error);
		}
	});
}

function updateInquiryInvestmentOptions() {
	const select = document.getElementById("estimated-investment");
	if (!select) return;

	const currency = CURRENCIES[activeCurrency] || CURRENCIES.PHP;
	const options = [
		{ value: "starter", label: "Starter Package", pricePhp: 8000 },
		{ value: "business", label: "Business Website", pricePhp: 18000 },
		{ value: "ecommerce", label: "E-Commerce Website", pricePhp: 45000 },
		{ value: "custom", label: "Custom Web Application", pricePhp: 0 },
		{ value: "unsure", label: "I'm Not Sure Yet", pricePhp: 0 },
	];

	const currentValue = select.value || options[0].value;
	select.innerHTML = options
		.map((option) => {
			const priceText = option.pricePhp > 0
				? ` — Starting at ${formatMoney(convertFromPhp(option.pricePhp, currency.code), currency.code)}`
				: "";
			return `<option value="${option.value}">${option.label}${priceText}</option>`;
		})
		.join("");

	if ([...select.options].some((option) => option.value === currentValue)) {
		select.value = currentValue;
	} else {
		select.value = options[0].value;
	}
}

/* --------------------------------------------------------------------------
   Currency / Pricing
   - All package & add-on amounts are stored in PHP (base currency).
   - Update PHP_TO_USD when the exchange rate changes.
   - Add new currencies in CURRENCIES and set their rateFromPhp.
   -------------------------------------------------------------------------- */

/** How many USD equal 1 PHP. Update this rate as needed. */
const PHP_TO_USD = 1 / 58;

/**
 * Currency registry — extend by adding entries (e.g. EUR).
 * rateFromPhp: multiply a PHP amount by this to get the display currency.
 */
const CURRENCIES = {
	PHP: {
		code: "PHP",
		label: "🇵🇭 PHP",
		symbol: "₱",
		locale: "en-PH",
		rateFromPhp: 1,
		decimals: 0,
	},
	USD: {
		code: "USD",
		label: "🇺🇸 USD",
		symbol: "$",
		locale: "en-US",
		rateFromPhp: PHP_TO_USD,
		decimals: 0,
	},
};

let activeCurrency = "PHP";
const priceAnimFrames = new WeakMap();

function convertFromPhp(amountPhp, currencyCode) {
	const currency = CURRENCIES[currencyCode] || CURRENCIES.PHP;
	return amountPhp * currency.rateFromPhp;
}

function formatMoney(amount, currencyCode) {
	const currency = CURRENCIES[currencyCode] || CURRENCIES.PHP;
	const rounded =
		currency.decimals === 0
			? Math.round(amount)
			: Number(amount.toFixed(currency.decimals));

	try {
		return new Intl.NumberFormat(currency.locale, {
			style: "currency",
			currency: currency.code,
			maximumFractionDigits: currency.decimals,
			minimumFractionDigits: currency.decimals,
		}).format(rounded);
	} catch {
		return `${currency.symbol}${rounded.toLocaleString(currency.locale)}`;
	}
}

function animatePrice(el, fromValue, toValue, currencyCode, suffix, duration = 420) {
	const prev = priceAnimFrames.get(el);
	if (prev) cancelAnimationFrame(prev);

	const start = performance.now();

	const tick = (now) => {
		const t = Math.min(1, (now - start) / duration);
		const eased = 1 - Math.pow(1 - t, 3);
		const current = fromValue + (toValue - fromValue) * eased;
		el.textContent = formatMoney(current, currencyCode) + suffix;
		el.classList.add("price-updating");

		if (t < 1) {
			priceAnimFrames.set(el, requestAnimationFrame(tick));
		} else {
			el.textContent = formatMoney(toValue, currencyCode) + suffix;
			el.classList.remove("price-updating");
			priceAnimFrames.delete(el);
		}
	};

	priceAnimFrames.set(el, requestAnimationFrame(tick));
}

function updatePricingDisplay(currencyCode, { animate = true } = {}) {
	const currency = CURRENCIES[currencyCode];
	if (!currency) return;

	const previousCurrency = activeCurrency;
	activeCurrency = currencyCode;

	document.querySelectorAll(".price-amount").forEach((el) => {
		const php = Number(el.dataset.pricePhp);
		if (Number.isNaN(php)) return;

		const suffix = el.dataset.suffix || "";
		const nextValue = convertFromPhp(php, currencyCode);

		if (!animate) {
			el.textContent = formatMoney(nextValue, currencyCode) + suffix;
			return;
		}

		const fromValue = convertFromPhp(php, previousCurrency);
		animatePrice(el, fromValue, nextValue, currencyCode, suffix);
	});
}

function setupPricingCurrency() {
	const select = document.getElementById("currency-select");
	if (!select) return;

	// Keep dropdown options in sync if currencies are added later
	const codes = Object.keys(CURRENCIES);
	if (select.options.length !== codes.length) {
		select.innerHTML = codes
			.map(
				(code) =>
					`<option value="${code}">${CURRENCIES[code].label}</option>`
			)
			.join("");
	}

	select.value = activeCurrency;
	updatePricingDisplay(activeCurrency, { animate: false });
	updateInquiryInvestmentOptions();

	select.addEventListener("change", (event) => {
		updatePricingDisplay(event.target.value, { animate: true });
		updateInquiryInvestmentOptions();
	});
}

renderServices();
renderPortfolio();
renderBusinessSolutions();
renderIndustries();
renderTechnologies();
setupPortfolioSlider();
setupMobileMenu();
setupPricingCurrency();
setupInquiryModal();
